<?php return array (
  'site_name' => 'GalGame群网盘',
  'password' => '789qwe./\\',
  'style' => 'material',
  'onedrive_root' => '/群网盘/',
  'cache_type' => 'secache',
  'cache_expire_time' => 3600,
  'cache_refresh_time' => 600,
  'root_path' => '?',
  'show' => 
  array (
    'stream' => 
    array (
      0 => 'txt',
    ),
    'image' => 
    array (
      0 => 'bmp',
      1 => 'jpg',
      2 => 'jpeg',
      3 => 'png',
      4 => 'gif',
    ),
    'video5' => 
    array (
      0 => 'mp4',
      1 => 'webm',
      2 => 'mkv',
    ),
    'video' => 
    array (
    ),
    'video2' => 
    array (
      0 => 'avi',
      1 => 'mpg',
      2 => 'mpeg',
      3 => 'rm',
      4 => 'rmvb',
      5 => 'mov',
      6 => 'wmv',
      7 => 'asf',
      8 => 'ts',
      9 => 'flv',
    ),
    'audio' => 
    array (
      0 => 'ogg',
      1 => 'mp3',
      2 => 'wav',
    ),
    'code' => 
    array (
      0 => 'html',
      1 => 'htm',
      2 => 'php',
      3 => 'css',
      4 => 'go',
      5 => 'java',
      6 => 'js',
      7 => 'json',
      8 => 'txt',
      9 => 'sh',
      10 => 'md',
    ),
    'doc' => 
    array (
      0 => 'csv',
      1 => 'doc',
      2 => 'docx',
      3 => 'odp',
      4 => 'ods',
      5 => 'odt',
      6 => 'pot',
      7 => 'potm',
      8 => 'potx',
      9 => 'pps',
      10 => 'ppsx',
      11 => 'ppsxm',
      12 => 'ppt',
      13 => 'pptm',
      14 => 'pptx',
      15 => 'rtf',
      16 => 'xls',
      17 => 'xlsx',
    ),
  ),
  'images' => 
  array (
    'home' => true,
    'public' => true,
    'exts' => 
    array (
      0 => 'jpg',
      1 => 'png',
      2 => 'gif',
      3 => 'bmp',
    ),
  ),
  'client_secret' => '9fF/AC17AQ5BYHOCLODkfnShBsmr-T=]',
  'client_id' => 'e1764c85-7f6e-4b99-b3db-6aee8e774c9e',
  'redirect_uri' => 'https://galbox.herokuapp.com/',
  'onedrive_hide' => '',
  'onedrive_hotlink' => '',
);